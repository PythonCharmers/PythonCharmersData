This dataset contains a sample of 100 patent applications taken from the ALTA
2018 shared task on patent classification.

https://inclass.kaggle.com/c/alta-2018-challenge

The text files are encoded in iso8859-1.
